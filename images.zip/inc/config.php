<?php
define("DB_HOST", "localhost");
define("DB_USER", "bdtechzo_rooti");
define("DB_PASS", "rooti");
define("DB_NAME", "bdtechzo_rooti_project");
define("TITLE", "Training with live project");
define("KEYWORDS", "PHP Tutorials, JAVA Tutorials, Oracle Database, C# Tutorials");